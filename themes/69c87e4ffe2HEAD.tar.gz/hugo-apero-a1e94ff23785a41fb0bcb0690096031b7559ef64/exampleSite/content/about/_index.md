---
title: "About"
description: |
  A website template for Hugo developed by RStudio & Formspree and available for free.
show_header: true
sidebar_left: false
# Keep this! Do not edit.
headless: false
cascade:
  headless: true
---

** index doesn't contain a body, just front matter above.
See the header / main / sidebar folders to edit the index.md files **
