---
title: "{{ replace .Name "-" " " | title }}"
subtitle: ""
excerpt: ""
date: {{ .Date }}
author: ""
draft: true
series:
tags:
categories:
layout: single # single or single-sidebar
---
